import cv2, json, subprocess, shutil
import numpy as np
from pathlib import Path

class Cancelled(Exception):
    pass

def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError(f"{cmd[0]} failed: {r.stderr[-300:]}")
    return r.stdout

def probe(path):
    j = json.loads(run(["ffprobe", "-v", "error", "-print_format", "json",
                        "-show_format", "-show_streams", str(path)]))
    v = next(s for s in j["streams"] if s["codec_type"] == "video")
    n, d = (v.get("avg_frame_rate") or "24/1").split("/")
    return dict(width=int(v["width"]), height=int(v["height"]),
                duration=float(j["format"]["duration"]),
                fps=round(float(n) / float(d), 2) if float(d) else 24.0)

LEGO_RGB = [(244,244,244),(160,165,169),(99,95,98),(27,42,52),(196,40,27),(123,46,47),(218,133,64),
 (245,205,47),(215,197,153),(204,142,104),(174,122,89),(246,215,179),(160,95,52),(105,64,39),(53,33,0),
 (149,138,115),(164,189,71),(40,127,70),(40,70,50),(13,105,171),(32,58,86),(110,153,201),(112,129,154),
 (252,151,172),(144,31,118),(160,110,185),(63,54,145),(255,176,0),(230,170,120),(190,110,80)]
_PAL_LAB = cv2.cvtColor(np.array([[c[::-1] for c in LEGO_RGB]], np.uint8), cv2.COLOR_BGR2LAB)[0].astype(np.float32)
_W = np.array([0.45, 1.4, 1.4], np.float32)
_PAL_BGR = np.array([c[::-1] for c in LEGO_RGB], np.uint8)

def stud_tile(b):
    t = np.ones((b, b), np.float32)
    t[0, :] = t[:, 0] = 0.78
    t[-1, :] = t[:, -1] = 0.9
    yy, xx = np.mgrid[0:b, 0:b]
    d = np.sqrt((xx - (b - 1) / 2) ** 2 + (yy - (b - 1) / 2) ** 2)
    r = b * 0.32
    t[d < r] = 1.1
    t[(d >= r) & (d < r + 1.0) & (xx + yy > b - 1)] = 0.88
    t[(d < r * 0.5) & (xx + yy < b)] = 1.2
    return t[..., None]

def sat(img, k):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype(np.float32)
    hsv[..., 1] = np.clip(hsv[..., 1] * k, 0, 255)
    return cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)

def make_styler(style, w, h):
    if style == "lego":
        b = max(6, round(w / 130))
        cols, rows = w // b, h // b
        full = np.tile(stud_tile(b), (rows, cols, 1))
        def f(img):
            sm = cv2.resize(img, (cols, rows), interpolation=cv2.INTER_AREA)
            sm = sat(cv2.bilateralFilter(sm, 5, 30, 3), 1.05)
            lab = cv2.cvtColor(sm, cv2.COLOR_BGR2LAB).reshape(-1, 3).astype(np.float32)
            d = (((lab[:, None, :] - _PAL_LAB[None]) ** 2) * _W).sum(-1)
            idx = d.argmin(1).reshape(rows, cols)
            small = _PAL_BGR[idx]
            big = cv2.resize(small, (cols * b, rows * b), interpolation=cv2.INTER_NEAREST)
            out = np.clip(big.astype(np.float32) * full, 0, 255).astype(np.uint8)
            return cv2.resize(out, (w, h)) if out.shape[:2] != (h, w) else out
        return f
    def f(img):  # smooth 3D-cartoon look
        k = 0.55
        sm = cv2.resize(img, (int(w * k) // 2 * 2, int(h * k) // 2 * 2), interpolation=cv2.INTER_AREA)
        c = sm
        for _ in range(2):
            c = cv2.bilateralFilter(c, 7, 40, 5)
        hsv = cv2.cvtColor(c, cv2.COLOR_BGR2HSV).astype(np.float32)
        v = hsv[..., 2] / 255.0
        hsv[..., 2] = (0.75 * v + 0.25 * np.round(v * 12) / 12) * 255
        hsv[..., 1] = np.clip(hsv[..., 1] * 1.18, 0, 255)
        c = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)
        g = cv2.GaussianBlur(cv2.cvtColor(c, cv2.COLOR_BGR2GRAY), (0, 0), 1.4)
        e = cv2.Canny(g, 45, 120)
        e = cv2.GaussianBlur(cv2.dilate(e, np.ones((2, 2), np.uint8)), (0, 0), 0.8).astype(np.float32) / 255
        c = (c.astype(np.float32) * (1 - 0.55 * e[..., None])).astype(np.uint8)
        out = cv2.resize(c, (w, h), interpolation=cv2.INTER_CUBIC)
        blur = cv2.GaussianBlur(out, (0, 0), 1.2)
        return cv2.addWeighted(out, 1.35, blur, -0.35, 0)
    return f

def stylize(src, dst, style, ev, prog):
    cap = cv2.VideoCapture(str(src))
    w, h = int(cap.get(3)), int(cap.get(4))
    fps = cap.get(5) or 24
    total = int(cap.get(7)) or 1
    vw = cv2.VideoWriter(str(dst), cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
    f = make_styler(style, w, h)
    i = 0
    while True:
        ok, img = cap.read()
        if not ok:
            break
        vw.write(f(img))
        i += 1
        if i % 5 == 0:
            if ev.is_set():
                raise Cancelled()
            prog(min(i / total, 1.0))
    cap.release(); vw.release()

def render_range(job_dir, src, start, dur, style, vf, out_path, ev, prog):
    tmp = Path(job_dir) / ("tmp_" + Path(out_path).stem)
    shutil.rmtree(tmp, ignore_errors=True); tmp.mkdir()
    try:
        a, b = tmp / "in.mp4", tmp / "silent.mp4"
        run(["ffmpeg", "-y", "-ss", str(start), "-i", str(src), "-t", str(dur),
             "-vf", vf, "-c:v", "libx264", "-preset", "ultrafast", "-crf", "14",
             "-c:a", "aac", "-b:a", "192k", str(a)])
        stylize(a, b, style, ev, prog)
        run(["ffmpeg", "-y", "-i", str(b), "-i", str(a), "-map", "0:v", "-map", "1:a?",
             "-c:v", "libx264", "-preset", "fast", "-crf", "16", "-pix_fmt", "yuv420p",
             "-c:a", "copy", "-shortest", str(out_path)])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
