import os, re, json, math, time, uuid, shutil, threading, queue
from pathlib import Path
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
import processor as P

DATA = Path(os.getenv("DATA_DIR", "/data")); JOBS = DATA / "jobs"; JOBS.mkdir(parents=True, exist_ok=True)
MAX_BYTES = int(float(os.getenv("MAX_UPLOAD_GB", "5")) * 1024 ** 3)
SEG = int(os.getenv("SEG_SECONDS", "60"))
app = FastAPI()
lock = threading.Lock()
q = queue.Queue()
events = {}

def jd(jid): return JOBS / jid
def load(jid):
    p = jd(jid) / "state.json"
    if not re.fullmatch(r"[0-9a-f]{10}", jid) or not p.exists():
        raise HTTPException(404, "job not found")
    return json.loads(p.read_text())
def save(s):
    p = jd(s["id"]) / "state.json"; t = p.with_suffix(".tmp")
    t.write_text(json.dumps(s)); t.replace(p)
def update(jid, **kw):
    with lock:
        s = load(jid); s.update(kw); save(s); return s
def throttled(jid, fn):
    last = [0.0]
    def cb(frac):
        if time.time() - last[0] > 1:
            last[0] = time.time(); fn(frac)
    return cb

def run_sample(jid, ev):
    s = load(jid)
    if s["status"] != "sample_running": return
    d = jd(jid)
    start = max(0, s["duration"] / 2 - 60)
    dur = min(120, s["duration"] - start)
    t0 = time.time()
    cb = throttled(jid, lambda f: update(jid, progress=round(f * 100, 1), message="Rendering 2-minute sample from the middle of the movie"))
    P.render_range(d, s["source"], start, dur, s["style"], s["height"], d / "sample.mp4", ev, cb)
    el = time.time() - t0
    update(jid, status="sample_ready", progress=100, sample_v=s.get("sample_v", 0) + 1,
           sample={"start": round(start), "seconds": round(dur), "elapsed": round(el, 1)},
           est_full_seconds=round(el / dur * s["duration"]), eta_seconds=None,
           message="Sample ready - review it, then approve full conversion")

def run_full(jid, ev):
    s = load(jid)
    if s["status"] != "full_running": return
    d = jd(jid); segd = d / "segs"; segd.mkdir(exist_ok=True)
    dur = s["duration"]; n = math.ceil(dur / SEG)
    def seglen(i): return min(SEG, dur - i * SEG)
    done_sec = sum(seglen(i) for i in range(n) if (segd / f"seg_{i:05d}.mp4").exists())
    base, t0 = done_sec, time.time()
    est = s.get("est_full_seconds") or dur
    def report(processed, msg):
        gained = processed - base
        eta = (time.time() - t0) / gained * (dur - processed) if gained > 1 else est * (dur - processed) / dur
        update(jid, progress=round(processed / dur * 100, 1), eta_seconds=round(eta), message=msg,
               segments_done=sum(1 for i in range(n) if (segd / f"seg_{i:05d}.mp4").exists()), segments_total=n)
    report(done_sec, "Starting / resuming")
    for i in range(n):
        out = segd / f"seg_{i:05d}.mp4"
        if out.exists(): continue
        ln = seglen(i); before = done_sec
        cb = throttled(jid, lambda f: report(before + f * ln, f"Segment {i + 1}/{n}"))
        part = segd / f"seg_{i:05d}.part.mp4"
        P.render_range(d, s["source"], i * SEG, ln, s["style"], s["height"], part, ev, cb)
        part.replace(out); done_sec += ln
        report(done_sec, f"Segment {i + 1}/{n} done")
    report(done_sec, "Joining segments")
    lst = d / "list.txt"
    lst.write_text("".join(f"file 'segs/seg_{i:05d}.mp4'\n" for i in range(n)))
    P.run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy",
           "-movflags", "+faststart", str(d / "final.mp4")])
    update(jid, status="full_done", progress=100, eta_seconds=0, message="Done - download your movie")

def worker():
    while True:
        jid, task = q.get()
        ev = events.setdefault(jid, threading.Event()); ev.clear()
        try:
            (run_sample if task == "sample" else run_full)(jid, ev)
        except P.Cancelled:
            update(jid, status="cancelled", message="Cancelled (finished segments are kept; you can resume)")
        except Exception as e:
            update(jid, status="error", message=str(e)[-300:])

def enqueue(jid, task, **kw):
    update(jid, status="sample_running" if task == "sample" else "full_running", progress=0, **kw)
    q.put((jid, task))

@app.on_event("startup")
def startup():
    threading.Thread(target=worker, daemon=True).start()
    for p in sorted(JOBS.glob("*/state.json")):
        s = json.loads(p.read_text())
        if s["status"] in ("sample_running", "full_running"):
            q.put((s["id"], "sample" if s["status"] == "sample_running" else "full"))

@app.put("/api/upload")
async def upload(request: Request, name: str, style: str = "lego", quality: str = "1080p", voice: bool = False):
    if style not in ("lego", "cartoon"): raise HTTPException(400, "bad style")
    if int(request.headers.get("content-length", 0)) > MAX_BYTES:
        raise HTTPException(413, f"File too large (limit {MAX_BYTES // 1024 ** 3} GB)")
    jid = uuid.uuid4().hex[:10]; d = jd(jid); d.mkdir(parents=True)
    ext = re.sub(r"[^a-z0-9]", "", Path(name).suffix.lower()) or "mp4"
    src = d / f"source.{ext}"; size = 0
    try:
        with open(src, "wb") as f:
            async for chunk in request.stream():
                size += len(chunk)
                if size > MAX_BYTES: raise HTTPException(413, "File too large")
                f.write(chunk)
        info = P.probe(src)
    except HTTPException:
        shutil.rmtree(d, ignore_errors=True); raise
    except Exception as e:
        shutil.rmtree(d, ignore_errors=True); raise HTTPException(400, f"Upload/probe failed: {e}")
    req = {"720p": 720, "1080p": 1080}.get(quality, info["height"])
    height = min(req, info["height"]) // 2 * 2
    s = dict(id=jid, name=name, size=size, source=str(src), src_width=info["width"], src_height=info["height"],
             duration=info["duration"], fps=info["fps"], height=height, style=style, quality=quality, voice=voice,
             created=time.time(), status="uploaded", progress=0, eta_seconds=None, message="", sample_v=0)
    save(s); enqueue(jid, "sample")
    return load(jid)

@app.get("/api/jobs")
def jobs():
    out = [json.loads(p.read_text()) for p in JOBS.glob("*/state.json")]
    return sorted(out, key=lambda s: -s["created"])

@app.get("/api/jobs/{jid}")
def job(jid: str): return load(jid)

@app.post("/api/jobs/{jid}/sample")
def resample(jid: str, style: str = "lego"):
    s = load(jid)
    if s["status"] in ("sample_running", "full_running"): raise HTTPException(409, "busy")
    if style not in ("lego", "cartoon"): raise HTTPException(400, "bad style")
    enqueue(jid, "sample", style=style)
    return load(jid)

@app.post("/api/jobs/{jid}/approve")
def approve(jid: str):
    s = load(jid)
    if s["status"] not in ("sample_ready", "cancelled", "error"): raise HTTPException(409, "sample not ready")
    shutil.rmtree(jd(jid) / "segs", ignore_errors=True) if s.get("seg_style") not in (None, s["style"]) else None
    enqueue(jid, "full", seg_style=s["style"])
    return load(jid)

@app.post("/api/jobs/{jid}/cancel")
def cancel(jid: str):
    load(jid); events.setdefault(jid, threading.Event()).set()
    update(jid, status="cancelled", message="Cancelling...")
    return load(jid)

@app.get("/api/jobs/{jid}/sample.mp4")
def sample(jid: str):
    p = jd(jid) / "sample.mp4"; load(jid)
    if not p.exists(): raise HTTPException(404)
    return FileResponse(p, media_type="video/mp4")

@app.get("/api/jobs/{jid}/download")
def download(jid: str):
    s = load(jid); p = jd(jid) / "final.mp4"
    if not p.exists(): raise HTTPException(404)
    return FileResponse(p, media_type="video/mp4", filename=f"{Path(s['name']).stem}_{s['style']}.mp4")

app.mount("/", StaticFiles(directory="static", html=True), name="static")
