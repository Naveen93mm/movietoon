import cv2, json, subprocess, shutil
import numpy as np
from pathlib import Path

class Cancelled(Exception):
    pass

def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError(f"{cmd[0]} failed: {r.stderr[-300:]}")
    return r.stdout

def probe(path):
    j = json.loads(run(["ffprobe", "-v", "error", "-print_format", "json",
                        "-show_format", "-show_streams", str(path)]))
    v = next(s for s in j["streams"] if s["codec_type"] == "video")
    n, d = (v.get("avg_frame_rate") or "24/1").split("/")
    return dict(width=int(v["width"]), height=int(v["height"]),
                duration=float(j["format"]["duration"]),
                fps=round(float(n) / float(d), 2) if float(d) else 24.0)

def stud_tile(b):
    t = np.ones((b, b), np.float32)
    t[0, :] = t[:, 0] = 0.7
    t[-1, :] = t[:, -1] = 0.85
    yy, xx = np.mgrid[0:b, 0:b]
    d = np.sqrt((xx - (b - 1) / 2) ** 2 + (yy - (b - 1) / 2) ** 2)
    r = b * 0.3
    t[d < r] = 1.12
    t[np.abs(d - r) < 0.8] = 0.8
    return t[..., None]

def make_styler(style, w, h):
    if style == "lego":
        b = max(8, round(w / 110))
        tile = stud_tile(b)
        cols, rows = w // b, h // b
        full = np.tile(tile, (rows, cols, 1))
        def f(img):
            sm = cv2.resize(img, (cols, rows), interpolation=cv2.INTER_AREA)
            sm = (sm // 48) * 48 + 24
            big = cv2.resize(sm, (cols * b, rows * b), interpolation=cv2.INTER_NEAREST)
            out = np.clip(big.astype(np.float32) * full, 0, 255).astype(np.uint8)
            return cv2.resize(out, (w, h)) if out.shape[:2] != (h, w) else out
        return f
    def f(img):  # 3D-cartoon style (cel-shaded) on CPU
        sm = cv2.resize(img, (w // 2, h // 2), interpolation=cv2.INTER_AREA)
        c = cv2.bilateralFilter(sm, 9, 50, 7)
        c = cv2.bilateralFilter(c, 9, 50, 7)
        c = (c // 32) * 32 + 16
        g = cv2.medianBlur(cv2.cvtColor(sm, cv2.COLOR_BGR2GRAY), 5)
        edges = cv2.adaptiveThreshold(g, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 9, 7)
        c = cv2.bitwise_and(c, c, mask=edges)
        return cv2.resize(c, (w, h), interpolation=cv2.INTER_LINEAR)
    return f

def stylize(src, dst, style, ev, prog):
    cap = cv2.VideoCapture(str(src))
    w, h = int(cap.get(3)), int(cap.get(4))
    fps = cap.get(5) or 24
    total = int(cap.get(7)) or 1
    vw = cv2.VideoWriter(str(dst), cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
    f = make_styler(style, w, h)
    i = 0
    while True:
        ok, img = cap.read()
        if not ok:
            break
        vw.write(f(img))
        i += 1
        if i % 5 == 0:
            if ev.is_set():
                raise Cancelled()
            prog(min(i / total, 1.0))
    cap.release(); vw.release()

def render_range(job_dir, src, start, dur, style, height, out_path, ev, prog):
    tmp = Path(job_dir) / ("tmp_" + Path(out_path).stem)
    shutil.rmtree(tmp, ignore_errors=True); tmp.mkdir()
    try:
        a, b = tmp / "in.mp4", tmp / "silent.mp4"
        run(["ffmpeg", "-y", "-ss", str(start), "-i", str(src), "-t", str(dur),
             "-vf", f"scale=-2:{height}", "-c:v", "libx264", "-preset", "ultrafast", "-crf", "17",
             "-c:a", "aac", "-b:a", "192k", str(a)])
        stylize(a, b, style, ev, prog)
        run(["ffmpeg", "-y", "-i", str(b), "-i", str(a), "-map", "0:v", "-map", "1:a?",
             "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p",
             "-c:a", "copy", "-shortest", str(out_path)])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
