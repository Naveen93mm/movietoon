#!/bin/bash
# Amazon Linux 2023 - one time setup, then start the app
set -e
sudo dnf install -y docker git
sudo systemctl enable --now docker
sudo usermod -aG docker $USER
sudo mkdir -p /usr/local/lib/docker/cli-plugins
sudo curl -SL https://github.com/docker/compose/releases/latest/download/docker-compose-linux-x86_64 -o /usr/local/lib/docker/cli-plugins/docker-compose
sudo chmod +x /usr/local/lib/docker/cli-plugins/docker-compose
echo "Setup done. Logout/login once, then run:  docker compose up -d --build"
